
import java.util.*;
 class Ass12
{
public static void main(String[] args) {
double radius = 7.5;
double PI = 3.17;

        double perimeter = 2 * PI * radius;//2pir
        double area = PI * radius * radius;//pir^2

        System.out.println("Perimeter is = " + perimeter);
        System.out.println("Area is = " + area);
    }
}