import java.util.*;
class Ass2
{
public static void main (String [] args)
{
int a,b,sum;
a=74;
b=36;
sum=a+b;
System.out.println(sum);
}
}