import java.util.*;
class Ass6
{
public static void main (String [] args)
{
int a,b,sum,sub,mul,div,mod;
a=125;
b=24;
sum=a+b;
sub=a-b;
mul=a*b;
div=a/b;
mod=a%b;
{
System.out.println("sum="+sum);
System.out.println("sub="+sub);
System.out.println("mul="+mul);
System.out.println("div="+div);
System.out.println("mod="+mod);
}
}
}