import java.util.*;
class Ass3
{
public static void main (String [] args)
{
int a,b,div;
a=50;
b=3;
div=a/b;
System.out.println(div);
}
}