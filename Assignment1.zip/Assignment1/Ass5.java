import java.util.*;
class Ass4
{
public static void main (String [] args)
{
int a,b,output;
a=25;
b=5;
output=a*b;
{
System.out.println("output="+output);
}
}
}